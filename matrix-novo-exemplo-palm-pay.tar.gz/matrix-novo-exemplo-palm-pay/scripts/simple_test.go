// <---- corrigido aqui: Teste mínimo da observabilidade (sem dependências complexas)

package tests

import (
	"context"
	"errors"
	"testing"
	"time"

	"novo-exemplo-palm-pay/utils/observabilidade"
)

// <---- corrigido aqui: Teste super simples da inicialização
func TestSimpleObservabilityInit(t *testing.T) {
	err := observabilidade.InitObservability("simple-test", "1.0.0")
	if err != nil {
		t.Fatalf("Failed to initialize observability: %v", err)
	}
	t.Log("✅ Observabilidade inicializada com sucesso!")
}

// <---- corrigido aqui: Teste básico do tracker
func TestSimpleTracker(t *testing.T) {
	// Inicializar observabilidade
	err := observabilidade.InitObservability("tracker-test", "1.0.0")
	if err != nil {
		t.Fatalf("Failed to initialize observability: %v", err)
	}

	// Criar tracker
	ctx := context.Background()
	tracker := observabilidade.StartOperation(ctx, "test", "simple_operation", "handler")

	if tracker == nil {
		t.Fatal("Tracker não deveria ser nil")
	}

	// Adicionar alguns dados
	tracker.AddParam("test_param", "test_value")
	tracker.AddResult("success", true)

	// Simular algum trabalho
	time.Sleep(5 * time.Millisecond)

	// Finalizar sem erro
	var testErr error
	tracker.Finish(&testErr)

	t.Log("✅ Tracker básico funcionou!")
}

// <---- corrigido aqui: Teste com erro
func TestSimpleTrackerWithError(t *testing.T) {
	// Inicializar observabilidade
	err := observabilidade.InitObservability("error-test", "1.0.0")
	if err != nil {
		t.Fatalf("Failed to initialize observability: %v", err)
	}

	// Criar tracker
	ctx := context.Background()
	tracker := observabilidade.StartOperation(ctx, "test", "error_operation", "service")

	// Adicionar dados
	tracker.AddParam("will_fail", true)

	// Simular erro
	testErr := errors.New("test error")
	tracker.Finish(&testErr)

	t.Log("✅ Tracker com erro funcionou!")
}

// <---- corrigido aqui: Teste dos wrappers básicos
func TestSimpleWrappers(t *testing.T) {
	// Inicializar observabilidade
	err := observabilidade.InitObservability("wrapper-test", "1.0.0")
	if err != nil {
		t.Fatalf("Failed to initialize observability: %v", err)
	}

	ctx := context.Background()

	// Teste handler wrapper
	handlerObs := observabilidade.NewHandlerObservability("test")
	if handlerObs == nil {
		t.Fatal("HandlerObservability não deveria ser nil")
	}

	handlerTracker := handlerObs.Track(ctx, "test_handler")
	if handlerTracker == nil {
		t.Fatal("Handler tracker não deveria ser nil")
	}

	var err1 error
	handlerTracker.Finish(&err1)

	// Teste service wrapper
	serviceObs := observabilidade.NewServiceObservability("test")
	if serviceObs == nil {
		t.Fatal("ServiceObservability não deveria ser nil")
	}

	serviceTracker := serviceObs.Track(ctx, "test_service")
	if serviceTracker == nil {
		t.Fatal("Service tracker não deveria ser nil")
	}

	var err2 error
	serviceTracker.Finish(&err2)

	// Teste repository wrapper
	repoObs := observabilidade.NewRepositoryObservability("test")
	if repoObs == nil {
		t.Fatal("RepositoryObservability não deveria ser nil")
	}

	repoTracker := repoObs.Track(ctx, "test_repo")
	if repoTracker == nil {
		t.Fatal("Repository tracker não deveria ser nil")
	}

	var err3 error
	repoTracker.Finish(&err3)

	// Teste query tracker
	queryTracker := repoObs.TrackQuery(ctx, "SELECT", "test_table")
	if queryTracker == nil {
		t.Fatal("Query tracker não deveria ser nil")
	}

	var err4 error
	queryTracker.Finish(&err4)

	t.Log("✅ Todos os wrappers funcionaram!")
}

// <---- corrigido aqui: Benchmark básico
func BenchmarkSimpleTracker(b *testing.B) {
	// Inicializar observabilidade uma vez
	err := observabilidade.InitObservability("benchmark", "1.0.0")
	if err != nil {
		b.Fatalf("Failed to initialize observability: %v", err)
	}

	ctx := context.Background()

	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tracker := observabilidade.StartOperation(ctx, "bench", "operation", "handler")
		tracker.AddParam("iteration", i)

		var err error
		tracker.Finish(&err)
	}
}
