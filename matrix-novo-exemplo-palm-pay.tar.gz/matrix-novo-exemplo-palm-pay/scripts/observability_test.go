package tests

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/labstack/echo/v4"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"novo-exemplo-palm-pay/utils/observabilidade"
)

// <---- corrigido aqui: Setup básico para testes
func setupTestObservability(t *testing.T) {
	err := observabilidade.InitObservability("test-service", "test-version")
	require.NoError(t, err, "Failed to initialize observability")
}

// <---- corrigido aqui: Teste do sistema de tracking
func TestObservabilityTracker(t *testing.T) {
	setupTestObservability(t)

	tests := []struct {
		name        string
		operation   string
		layer       string
		shouldError bool
		errorMsg    string
	}{
		{
			name:      "successful handler operation",
			operation: "test_operation",
			layer:     "handler",
		},
		{
			name:      "successful service operation",
			operation: "test_service_op",
			layer:     "service",
		},
		{
			name:      "successful repository operation",
			operation: "test_repo_op",
			layer:     "repository",
		},
		{
			name:        "handler operation with error",
			operation:   "test_error_op",
			layer:       "handler",
			shouldError: true,
			errorMsg:    "test validation error",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctx := context.Background()

			// Simular operação com tracker
			tracker := observabilidade.StartOperation(ctx, "test", tt.operation, tt.layer)

			// Adicionar alguns parâmetros de teste
			tracker.AddParam("test_param", "test_value")
			tracker.AddParam("numeric_param", 123)

			// Simular trabalho
			time.Sleep(10 * time.Millisecond)

			var err error
			if tt.shouldError {
				err = errors.New(tt.errorMsg)
			}

			// Adicionar resultado de teste
			tracker.AddResult("test_result", "success")

			// Finalizar tracker
			tracker.Finish(&err)

			// Verificar que não houve panic
			assert.True(t, true, "Tracker completed without panic")
		})
	}
}

// <---- corrigido aqui: Teste dos wrappers por camada
func TestLayerWrappers(t *testing.T) {
	setupTestObservability(t)

	t.Run("handler wrapper", func(t *testing.T) {
		handlerObs := observabilidade.NewHandlerObservability("test")

		tracker := handlerObs.Track(context.Background(), "test_handler_op")
		tracker.AddParam("user_id", "123")

		var err error
		tracker.Finish(&err)

		assert.NotNil(t, tracker)
	})

	t.Run("service wrapper", func(t *testing.T) {
		serviceObs := observabilidade.NewServiceObservability("test")

		tracker := serviceObs.Track(context.Background(), "test_service_op")
		tracker.AddParam("entity_id", 456)

		var err error
		tracker.Finish(&err)

		assert.NotNil(t, tracker)
	})

	t.Run("repository wrapper", func(t *testing.T) {
		repoObs := observabilidade.NewRepositoryObservability("test")

		// Teste do tracker normal
		tracker := repoObs.Track(context.Background(), "test_repo_op")
		var err error
		tracker.Finish(&err)
		assert.NotNil(t, tracker)

		// Teste do tracker de query
		queryTracker := repoObs.TrackQuery(context.Background(), "SELECT", "test_table")
		queryTracker.AddParam("id", 789)
		queryTracker.Finish(&err)
		assert.NotNil(t, queryTracker)
	})
}

// <---- corrigido aqui: Teste dos middlewares
func TestObservabilityMiddlewares(t *testing.T) {
	setupTestObservability(t)

	t.Run("request ID middleware", func(t *testing.T) {
		e := echo.New()
		e.Use(observabilidade.RequestIDMiddleware())

		e.GET("/test", func(c echo.Context) error {
			// Verificar se Request ID foi adicionado
			requestID := c.Get("request_id")
			assert.NotNil(t, requestID)
			assert.NotEmpty(t, requestID)

			// Verificar se está no contexto
			ctxRequestID := observabilidade.GetRequestIDFromContext(c.Request().Context())
			assert.NotEqual(t, "unknown", ctxRequestID)

			return c.JSON(http.StatusOK, map[string]string{"request_id": requestID.(string)})
		})

		req := httptest.NewRequest(http.MethodGet, "/test", nil)
		rec := httptest.NewRecorder()

		e.ServeHTTP(rec, req)

		assert.Equal(t, http.StatusOK, rec.Code)
		assert.NotEmpty(t, rec.Header().Get("X-Request-ID"))
	})

	t.Run("request ID middleware with existing header", func(t *testing.T) {
		e := echo.New()
		e.Use(observabilidade.RequestIDMiddleware())

		e.GET("/test", func(c echo.Context) error {
			requestID := c.Get("request_id")
			return c.JSON(http.StatusOK, map[string]string{"request_id": requestID.(string)})
		})

		req := httptest.NewRequest(http.MethodGet, "/test", nil)
		req.Header.Set("X-Request-ID", "existing-request-id")
		rec := httptest.NewRecorder()

		e.ServeHTTP(rec, req)

		assert.Equal(t, http.StatusOK, rec.Code)
		assert.Equal(t, "existing-request-id", rec.Header().Get("X-Request-ID"))
	})

	t.Run("timeout middleware", func(t *testing.T) {
		e := echo.New()
		e.Use(observabilidade.TimeoutMiddleware(50 * time.Millisecond))

		e.GET("/test", func(c echo.Context) error {
			// Verificar se contexto tem deadline
			_, hasDeadline := c.Request().Context().Deadline()
			assert.True(t, hasDeadline)

			return c.JSON(http.StatusOK, map[string]string{"status": "ok"})
		})

		req := httptest.NewRequest(http.MethodGet, "/test", nil)
		rec := httptest.NewRecorder()

		e.ServeHTTP(rec, req)

		assert.Equal(t, http.StatusOK, rec.Code)
	})

	t.Run("enhanced HTTP metrics middleware", func(t *testing.T) {
		e := echo.New()
		e.Use(observabilidade.EnhancedHTTPMetricsMiddleware("test"))

		e.GET("/test", func(c echo.Context) error {
			return c.JSON(http.StatusOK, map[string]string{"status": "ok"})
		})

		req := httptest.NewRequest(http.MethodGet, "/test", nil)
		rec := httptest.NewRecorder()

		e.ServeHTTP(rec, req)

		assert.Equal(t, http.StatusOK, rec.Code)
	})
}

// <---- corrigido aqui: Teste de integração completa
func TestFullObservabilityIntegration(t *testing.T) {
	setupTestObservability(t)

	// Simular uma requisição completa passando por todas as camadas
	ctx := context.Background()

	// 1. Handler layer
	handlerObs := observabilidade.NewHandlerObservability("integration_test")
	handlerTracker := handlerObs.Track(ctx, "full_operation")
	handlerTracker.AddParam("user_id", "test-user")

	// 2. Service layer (dentro do handler)
	serviceObs := observabilidade.NewServiceObservability("integration_test")
	serviceTracker := serviceObs.Track(ctx, "business_logic")
	serviceTracker.AddParam("entity_type", "test_entity")

	// 3. Repository layer (dentro do service)
	repoObs := observabilidade.NewRepositoryObservability("integration_test")
	repoTracker := repoObs.TrackQuery(ctx, "SELECT", "test_table")
	repoTracker.AddParam("query_id", "test-query-123")

	// Simular trabalho em cada camada
	time.Sleep(5 * time.Millisecond)

	// Finalizar em ordem reversa (como seria na prática)
	var err error

	// Repository finaliza primeiro
	repoTracker.AddResult("rows_found", 5)
	repoTracker.Finish(&err)

	// Service finaliza
	serviceTracker.AddResult("processed", true)
	serviceTracker.Finish(&err)

	// Handler finaliza por último
	handlerTracker.AddResult("response_status", 200)
	handlerTracker.Finish(&err)

	// Se chegou até aqui sem panic, o teste passou
	assert.True(t, true, "Full integration completed successfully")
}

// <---- corrigido aqui: Teste de cenários de erro
func TestObservabilityErrorScenarios(t *testing.T) {
	setupTestObservability(t)

	errorScenarios := []struct {
		name      string
		errorType string
		errorMsg  string
	}{
		{
			name:      "validation error",
			errorType: "validation",
			errorMsg:  "invalid input parameter",
		},
		{
			name:      "timeout error",
			errorType: "timeout",
			errorMsg:  "operation timed out after deadline exceeded",
		},
		{
			name:      "network error",
			errorType: "network",
			errorMsg:  "connection refused to database server",
		},
		{
			name:      "not found error",
			errorType: "not_found",
			errorMsg:  "record not found in database",
		},
	}

	for _, scenario := range errorScenarios {
		t.Run(scenario.name, func(t *testing.T) {
			ctx := context.Background()
			tracker := observabilidade.StartOperation(ctx, "error_test", scenario.name, "handler")

			// Simular erro
			err := errors.New(scenario.errorMsg)

			tracker.AddParam("error_scenario", scenario.errorType)
			tracker.Finish(&err)

			// Verificar que o tracker lidou com o erro sem panic
			assert.True(t, true, "Error scenario handled correctly")
		})
	}
}

// <---- corrigido aqui: Benchmark da observabilidade
func BenchmarkObservabilityTracker(b *testing.B) {
	err := observabilidade.InitObservability("benchmark-service", "1.0.0")
	require.NoError(b, err)

	ctx := context.Background()

	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tracker := observabilidade.StartOperation(ctx, "benchmark", "test_op", "handler")
		tracker.AddParam("iteration", i)
		tracker.AddResult("completed", true)

		var err error
		tracker.Finish(&err)
	}
}
