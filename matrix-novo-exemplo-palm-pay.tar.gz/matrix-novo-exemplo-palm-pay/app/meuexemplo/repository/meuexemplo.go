package meuexemploRepo

import (
	"context"
	"errors"
	"time"

	"novo-exemplo-palm-pay/model"
	"novo-exemplo-palm-pay/utils/observabilidade" // <---- adicionado aqui

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/tungstenbyte/utils/logger"
)

type MeuexemploRepositoryIF interface {
	GetMeuexemplo(ctx context.Context, offset int64, limit int64) (model.ItemsPage, error)
	GetMeuexemploById(ctx context.Context, id int64) (*model.Meuexemplo, error)
	GetMeuexemploByStatusCode(ctx context.Context, statuscode string) (*model.Meuexemplo, error)
	InsertMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo) (int64, error)
	UpdateMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo, id int64) error
	DeleteMeuexemploById(ctx context.Context, id int64) (bool, error)
}

type MeuexemploRepository struct {
	PGRead        *pgxpool.Pool
	PGWrite       *pgxpool.Pool
	log           logger.Logger
	observability *observabilidade.RepositoryObservability // <---- adicionado aqui
}

func NewMeuexemploRepository(pgWrite *pgxpool.Pool, pgRead *pgxpool.Pool, log logger.Logger) *MeuexemploRepository {
	return &MeuexemploRepository{
		log:           log,
		PGWrite:       pgWrite,
		PGRead:        pgRead,
		observability: observabilidade.NewRepositoryObservability("meuexemplo"), // <---- adicionado aqui
	}
}

func (t MeuexemploRepository) GetMeuexemplo(ctx context.Context, offset int64, limit int64) (itemsPage model.ItemsPage, err error) {
	startedAt := time.Now()
	defer t.log.Chronometer("MeuexemploRepository -> GetMeuexemplo", &startedAt)

	// <---- adicionado aqui: UMA LINHA = observabilidade completa + métricas de DB!
	tracker := t.observability.TrackQuery(ctx, "SELECT", "repository.GetMeuexemplo")
	defer tracker.Finish(&err)

	tracker.AddParam("offset", offset)
	tracker.AddParam("limit", limit)

	meuexemplos := []model.Meuexemplo{}

	rows, err := t.PGRead.Query(ctx, SQL_MEUEXEMPLO_LIST, limit, offset)
	if err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.GetMeuexemplos.PG: ", err.Error())
		return itemsPage, err
	}
	defer rows.Close()

	for rows.Next() {
		var meuexemplo model.Meuexemplo
		err = rows.Scan(
			&meuexemplo.ID,
			&meuexemplo.StatusCode,
			&meuexemplo.Name,
			&meuexemplo.Description,
			&meuexemplo.AllowsTransactions,
			&meuexemplo.MaxTransactionAmount,
			&meuexemplo.CreatedAt,
			&meuexemplo.UpdatedAt,
		)
		if err != nil {
			t.log.Error(ctx, "MeuexemploRepository.repository.GetMeuexemplos.Scan: ", err.Error())
			return itemsPage, err
		}
		meuexemplos = append(meuexemplos, meuexemplo)
	}

	if err = rows.Err(); err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.GetMeuexemplos.Rows: ", err.Error())
		return itemsPage, err
	}

	qtyRecords := int64(0)
	if len(meuexemplos) > 0 {
		qtyRecords = meuexemplos[0].FullCount
	}

	itemsPage.Offset = offset
	itemsPage.Limit = limit
	itemsPage.Total = qtyRecords
	itemsPage.Items = meuexemplos

	// <---- adicionado aqui: Adicionar resultado ao tracker
	tracker.AddResult("rows_returned", len(meuexemplos))
	tracker.AddResult("total_count", qtyRecords)

	return itemsPage, nil
}

func (t MeuexemploRepository) GetMeuexemploById(ctx context.Context, id int64) (meuexemplo *model.Meuexemplo, err error) {
	startedAt := time.Now()
	defer t.log.Chronometer("MeuexemploRepository -> GetMeuexemploById", &startedAt)

	tracker := t.observability.TrackQuery(ctx, "SELECT", "repository.GetMeuexemploById")
	defer tracker.Finish(&err)

	tracker.AddParam("repository.GetMeuexemploById.id", id)

	meuexemplo = new(model.Meuexemplo)
	row := t.PGRead.QueryRow(ctx, SQL_GET_MEUEXEMPLO_BY_ID, id)

	err = row.Scan(
		&meuexemplo.ID,
		&meuexemplo.StatusCode,
		&meuexemplo.Name,
		&meuexemplo.Description,
		&meuexemplo.AllowsTransactions,
		&meuexemplo.MaxTransactionAmount,
		&meuexemplo.CreatedAt,
		&meuexemplo.UpdatedAt,
	)
	if err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.GetMeuexemploById: ", err.Error())
		return nil, err
	}

	tracker.AddResult("repository.GetMeuexemploById.found", true)
	return meuexemplo, nil
}

func (t MeuexemploRepository) GetMeuexemploByStatusCode(ctx context.Context, statuscode string) (meuexemplo *model.Meuexemplo, err error) {
	startedAt := time.Now()
	defer t.log.Chronometer("MeuexemploRepository -> GetMeuexemploByStatusCode", &startedAt)

	tracker := t.observability.TrackQuery(ctx, "SELECT", "repository.GetMeuexemploByStatusCode")
	defer tracker.Finish(&err)

	tracker.AddParam("repository.GetMeuexemploByStatusCode.status_code", statuscode)

	meuexemplo = new(model.Meuexemplo)
	row := t.PGRead.QueryRow(ctx, SQL_GET_MEUEXEMPLO_BY_STATUS_CODE, statuscode)

	err = row.Scan(
		&meuexemplo.ID,
		&meuexemplo.StatusCode,
		&meuexemplo.Name,
		&meuexemplo.Description,
		&meuexemplo.AllowsTransactions,
		&meuexemplo.MaxTransactionAmount,
		&meuexemplo.CreatedAt,
		&meuexemplo.UpdatedAt,
	)
	if err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.GetMeuexemploBystatuscode: ", err.Error())
		return nil, err
	}

	tracker.AddResult("found", true)
	return meuexemplo, nil
}

func (t MeuexemploRepository) DeleteMeuexemploById(ctx context.Context, id int64) (result bool, err error) {
	startedAt := time.Now()
	defer t.log.Chronometer("MeuexemploRepository -> DeleteMeuexemploById", &startedAt)

	tracker := t.observability.TrackQuery(ctx, "DELETE", "repository.DeleteMeuexemploById")
	defer tracker.Finish(&err)

	tracker.AddParam("id", id)

	commandTag, err := t.PGWrite.Exec(ctx, SQL_MEUEXEMPLO_DELETE_BY_ID, id)
	if err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.DeleteMeuexemploById: ", err.Error())
		return false, err
	}

	rowsAffected := commandTag.RowsAffected()
	result = rowsAffected > 0

	tracker.AddResult("repository.DeleteMeuexemploById.rows_affected", rowsAffected)
	tracker.AddResult("repository.DeleteMeuexemploById.deleted", result)

	return result, nil
}

func (t MeuexemploRepository) InsertMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo) (insertedID int64, err error) {
	startedAt := time.Now()
	defer t.log.Chronometer("MeuexemploRepository -> InsertMeuexemplo", &startedAt)

	tracker := t.observability.TrackQuery(ctx, "INSERT", "repository.InsertMeuexemplo")
	defer tracker.Finish(&err)

	tracker.AddParam("repository.InsertMeuexemplo.name", meuexemplo.Name)
	tracker.AddParam("repository.InsertMeuexemplo.status_code", meuexemplo.StatusCode)

	err = t.PGWrite.QueryRow(ctx, SQL_MEUEXEMPLO_INSERT,
		meuexemplo.StatusCode,
		meuexemplo.Name,
		meuexemplo.Description,
		meuexemplo.AllowsTransactions,
		meuexemplo.MaxTransactionAmount,
		meuexemplo.CreatedAt,
		meuexemplo.UpdatedAt,
	).Scan(&meuexemplo.ID)

	if err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.InsertMeuexemplo.PG: ", err.Error())
		return 0, err
	}

	tracker.AddResult("inserted_id", meuexemplo.ID)
	return meuexemplo.ID, nil
}

func (t MeuexemploRepository) UpdateMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo, id int64) (err error) {
	startedAt := time.Now()
	defer t.log.Chronometer("MeuexemploRepository -> UpdateMeuexemplo", &startedAt)

	tracker := t.observability.TrackQuery(ctx, "UPDATE", "repository.UpdateMeuexemplo")
	defer tracker.Finish(&err)

	tracker.AddParam("repository.UpdateMeuexemplo.id", id)
	tracker.AddParam("repository.UpdateMeuexemplo.name", meuexemplo.Name)
	tracker.AddParam("repository.UpdateMeuexemplo.status_code", meuexemplo.StatusCode)

	meuexemplo.ID = id

	commandTag, err := t.PGWrite.Exec(ctx, SQL_MEUEXEMPLO_UPDATE,
		meuexemplo.StatusCode,
		meuexemplo.Name,
		meuexemplo.Description,
		meuexemplo.AllowsTransactions,
		meuexemplo.MaxTransactionAmount,
		meuexemplo.CreatedAt,
		meuexemplo.UpdatedAt,
		meuexemplo.ID,
	)
	if err != nil {
		t.log.Error(ctx, "MeuexemploRepository.repository.UpdateMeuexemplo.PG: ", err.Error())
		return err
	}

	rowsAffected := commandTag.RowsAffected()
	if rowsAffected == 0 {
		err = errors.New("no rows affected")
		t.log.Error(ctx, "CustomerRepository.repository.UpdateMeuexemplo.PG: ", err)
		return err
	}

	tracker.AddResult("repository.UpdateMeuexemplo.rows_affected", rowsAffected)
	return nil
}
