package meuexemploRepo

var (
	SQL_MEUEXEMPLO_LIST = `
       SELECT 
              id, 
              status_code, 
              name, 
              description, 
              allows_transactions, 
              max_transaction_amount, 
              created_at, 
              updated_at 
         FROM meuexemplo
         ORDER BY id LIMIT $1 OFFSET $2
       ;`

	SQL_MEUEXEMPLO_INSERT = `
       INSERT INTO meuexemplo(
              status_code, 
              name, 
              description, 
              allows_transactions, 
              max_transaction_amount, 
              created_at, 
              updated_at) 
       VALUES( 
              $1, 
              $2, 
              $3, 
              $4, 
              $5, 
              $6, 
              $7) RETURNING id;`

	SQL_MEUEXEMPLO_UPDATE = `
       UPDATE meuexemplo SET 
              status_code = $1, 
              name = $2, 
              description = $3, 
              allows_transactions = $4, 
              max_transaction_amount = $5, 
              created_at = $6, 
              updated_at = $7 
        WHERE id = $8; `

	SQL_MEUEXEMPLO_DELETE_BY_ID = `
       DELETE FROM meuexemplo
        WHERE id = $1; `

	SQL_GET_MEUEXEMPLO_BY_ID = `
       SELECT 
              id, 
              status_code, 
              name, 
              description, 
              allows_transactions, 
              max_transaction_amount, 
              created_at, 
              updated_at 
         FROM meuexemplo
        WHERE id = $1; `

	SQL_GET_MEUEXEMPLO_BY_STATUS_CODE = `
       SELECT 
              id, 
              status_code, 
              name, 
              description, 
              allows_transactions, 
              max_transaction_amount, 
              created_at, 
              updated_at 
         FROM meuexemplo
        WHERE Status_code  LIKE '%' || $1 || '%' ; `
)
