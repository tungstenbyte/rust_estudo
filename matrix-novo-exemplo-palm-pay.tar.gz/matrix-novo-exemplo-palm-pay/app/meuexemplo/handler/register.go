package meuexemploHandler

import (
	meuexemploSV "novo-exemplo-palm-pay/app/meuexemplo/service"
	"novo-exemplo-palm-pay/utils/observabilidade" // <---- adicionado aqui

	"github.com/labstack/echo/v4"
	"github.com/tungstenbyte/utils/logger"
)

func RegisterMeuexemploHTTPEndpoints(router *echo.Group, uc meuexemploSV.MeuexemploServiceIF, log logger.Logger) {
	h := NewMeuexemploHandler(uc, log)

	// <---- adicionado aqui: Usar o middleware aprimorado com grupo específico
	meuexemploGroup := router.Group("/meuexemplo", observabilidade.EnhancedHTTPMetricsMiddleware("meuexemplo"))
	{
		meuexemploGroup.GET("", h.GetMeuexemplo)         // <---- adicionado aqui: ""
		meuexemploGroup.GET("/:id", h.GetMeuexemploById) // <---- adicionado aqui: "/:id"
		meuexemploGroup.GET("/statuscode/:statuscode", h.GetMeuexemploByStatusCode)
		meuexemploGroup.POST("", h.InsertMeuexemplo)           // <---- adicionado aqui: ""
		meuexemploGroup.PUT("/:id", h.UpdateMeuexemplo)        // <---- adicionado aqui: "/:id"
		meuexemploGroup.DELETE("/:id", h.DeleteMeuexemploById) // <---- adicionado aqui: "/:id"
	}
}
