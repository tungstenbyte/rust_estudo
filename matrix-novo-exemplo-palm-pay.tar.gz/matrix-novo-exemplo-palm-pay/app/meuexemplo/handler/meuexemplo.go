package meuexemploHandler

import (
	"net/http"
	"strconv"
	"time"

	app "novo-exemplo-palm-pay/app"
	meuexemploSV "novo-exemplo-palm-pay/app/meuexemplo/service"
	"novo-exemplo-palm-pay/model"
	"novo-exemplo-palm-pay/utils/observabilidade" // <---- adicionado aqui

	"github.com/labstack/echo/v4"
	"github.com/tungstenbyte/utils/logger"
)

type Handler struct {
	serviceIF     meuexemploSV.MeuexemploServiceIF
	log           logger.Logger
	observability *observabilidade.HandlerObservability // <---- adicionado aqui: Um único observador
}

func NewMeuexemploHandler(service meuexemploSV.MeuexemploServiceIF, log logger.Logger) *Handler {
	return &Handler{
		log:           log,
		serviceIF:     service,
		observability: observabilidade.NewHandlerObservability("meuexemplo"), // <---- adicionado aqui
	}
}

func (h Handler) GetMeuexemplo(c echo.Context) (err error) {
	startedAt := time.Now()
	defer h.log.Chronometer("MeuexemploHandle -> GetMeuexemplo", &startedAt)

	// <---- adicionado aqui: UMA ÚNICA LINHA para observabilidade completa!
	tracker := h.observability.Track(c.Request().Context(), "get_list")
	defer tracker.Finish(&err) // <---- adicionado aqui: Captura TUDO automaticamente

	limitParam := c.QueryParam("limit")
	offsetParam := c.QueryParam("offset")

	// <---- adicionado aqui: Adicionar parâmetros ao tracker (opcional)
	tracker.AddParam("limit", limitParam)
	tracker.AddParam("offset", offsetParam)

	limit, err := strconv.ParseInt(limitParam, 10, 64)
	if err != nil {
		// <---- adicionado aqui: Tracker captura automaticamente erro de validação
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgOffsetLimit,
		})
	}

	offset, err := strconv.ParseInt(offsetParam, 10, 64)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgOffsetLimit,
		})
	}

	result, err := h.serviceIF.GetMeuexemplo(c.Request().Context(), offset, limit)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	// <---- adicionado aqui: Adicionar resultado ao tracker (opcional)
	if items, ok := result.Items.([]model.Meuexemplo); ok {
		tracker.AddResult("count", len(items))
		tracker.AddResult("total", result.Total)
	}

	return c.JSON(http.StatusOK, &result)
	// <---- adicionado aqui: defer tracker.Finish(&err) captura TUDO automaticamente:
	// ✅ Duração total
	// ✅ Status de sucesso/erro
	// ✅ Tipo de erro (validação, service, etc)
	// ✅ Métricas por camada
	// ✅ Logs estruturados
	// ✅ Timeouts
	// ✅ Request ID
}

func (h Handler) GetMeuexemploById(c echo.Context) (err error) {
	startedAt := time.Now()
	defer h.log.Chronometer("MeuexemploHandle -> GetMeuexemploById", &startedAt)

	// <---- adicionado aqui: UMA linha = observabilidade completa
	tracker := h.observability.Track(c.Request().Context(), "get_by_id")
	defer tracker.Finish(&err)

	idParam := c.Param("id")
	tracker.AddParam("id", idParam)

	id, err := strconv.ParseInt(idParam, 10, 64)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	result, err := h.serviceIF.GetMeuexemploById(c.Request().Context(), id)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	tracker.AddResult("found", result != nil)
	if result != nil {
		tracker.AddResult("id", result.ID)
	}

	return c.JSON(http.StatusOK, &result)
}

func (h Handler) GetMeuexemploByStatusCode(c echo.Context) (err error) {
	startedAt := time.Now()
	defer h.log.Chronometer("MeuexemploHandle -> GetMeuexemploByStatusCode", &startedAt)

	tracker := h.observability.Track(c.Request().Context(), "handler.GetMeuexemploByStatusCode")
	defer tracker.Finish(&err)

	statuscode := c.Param("statuscode")
	tracker.AddParam("handler.GetMeuexemploByStatusCode.status_code", statuscode)

	if statuscode == "" {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	result, err := h.serviceIF.GetMeuexemploByStatusCode(c.Request().Context(), statuscode)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	tracker.AddResult("handler.GetMeuexemploByStatusCode.found", result != nil)
	return c.JSON(http.StatusOK, &result)
}

func (h Handler) DeleteMeuexemploById(c echo.Context) (err error) {
	startedAt := time.Now()
	defer h.log.Chronometer("MeuexemploHandle -> DeleteMeuexemploById", &startedAt)

	tracker := h.observability.Track(c.Request().Context(), "handler.DeleteMeuexemploById")
	defer tracker.Finish(&err)

	idParam := c.Param("id")
	tracker.AddParam("handler.DeleteMeuexemploById.id", idParam)

	id, err := strconv.ParseInt(idParam, 10, 64)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	deleted, err := h.serviceIF.DeleteMeuexemploById(c.Request().Context(), id)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{
			app.Message: app.MsgInternalError,
		})
	}

	if !deleted {
		tracker.AddResult("handler.DeleteMeuexemploById.not_found", true)
		return c.JSON(http.StatusNotFound, map[string]string{
			app.Message: "Item not found",
		})
	}

	tracker.AddResult(".handler.DeleteMeuexemploById.deleted", true)
	return c.NoContent(http.StatusNoContent)
}

func (h Handler) InsertMeuexemplo(c echo.Context) (err error) {
	startedAt := time.Now()
	defer h.log.Chronometer("MeuexemploHandle -> InsertMeuexemplo", &startedAt)

	tracker := h.observability.Track(c.Request().Context(), "handler.InsertMeuexemplo")
	defer tracker.Finish(&err)

	meuexemplo := new(model.Meuexemplo)
	err = c.Bind(meuexemplo)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	// <---- adicionado aqui: Adicionar dados do objeto ao tracker
	tracker.AddParam("handler.InsertMeuexemplo.name", meuexemplo.Name)
	tracker.AddParam("handler.InsertMeuexemplo.status_code", meuexemplo.StatusCode)

	if meuexemplo.Name == "" {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: "Name is required",
		})
	}

	insertedId, err := h.serviceIF.InsertMeuexemplo(c.Request().Context(), meuexemplo)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{
			app.Message: app.MsgInternalError,
		})
	}

	tracker.AddResult("handler.InsertMeuexemplo.inserted_id", insertedId)
	return c.JSON(http.StatusCreated, map[string]interface{}{
		"id": insertedId,
	})
}

func (h Handler) UpdateMeuexemplo(c echo.Context) (err error) {
	startedAt := time.Now()
	defer h.log.Chronometer("MeuexemploHandle -> UpdateMeuexemplo", &startedAt)

	tracker := h.observability.Track(c.Request().Context(), "handler.UpdateMeuexemplo")
	defer tracker.Finish(&err)

	idParam := c.Param("id")
	tracker.AddParam("handler.UpdateMeuexemplo.id", idParam)

	id, err := strconv.ParseInt(idParam, 10, 64)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	meuexemplo := new(model.Meuexemplo)
	err = c.Bind(meuexemplo)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{
			app.Message: app.MsgBadRequest,
		})
	}

	tracker.AddParam("name", meuexemplo.Name)
	tracker.AddParam("handler.UpdateMeuexemplo.status_code", meuexemplo.StatusCode)

	err = h.serviceIF.UpdateMeuexemplo(c.Request().Context(), meuexemplo, id)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{
			app.Message: app.MsgInternalError,
		})
	}

	tracker.AddResult("handler.UpdateMeuexemplo.updated", true)
	return c.NoContent(http.StatusNoContent)
}
