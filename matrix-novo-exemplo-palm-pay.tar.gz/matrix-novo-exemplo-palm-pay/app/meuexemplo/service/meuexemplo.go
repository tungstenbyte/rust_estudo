package meuexemploSV

import (
	"context"
	"errors"
	"time"

	app "novo-exemplo-palm-pay/app"
	meuexemploRepo "novo-exemplo-palm-pay/app/meuexemplo/repository"
	model "novo-exemplo-palm-pay/model"
	"novo-exemplo-palm-pay/utils/observabilidade" // <---- adicionado aqui

	"github.com/tungstenbyte/utils/logger"
)

type MeuexemploServiceIF interface {
	GetMeuexemplo(ctx context.Context, offset int64, limit int64) (model.ItemsPage, error)
	GetMeuexemploById(ctx context.Context, id int64) (*model.Meuexemplo, error)
	GetMeuexemploByStatusCode(ctx context.Context, statuscode string) (*model.Meuexemplo, error)
	InsertMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo) (int64, error)
	UpdateMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo, id int64) error
	DeleteMeuexemploById(ctx context.Context, id int64) (bool, error)
}

type Resource struct {
	meuexemploRepo meuexemploRepo.MeuexemploRepositoryIF
	log            logger.Logger
	observability  *observabilidade.ServiceObservability // <---- adicionado aqui
}

func NewMeuexemploService(meuexemploRepo meuexemploRepo.MeuexemploRepositoryIF, log logger.Logger) *Resource {
	return &Resource{
		log:            log,
		meuexemploRepo: meuexemploRepo,
		observability:  observabilidade.NewServiceObservability("service.meuexemplo"), // <---- adicionado aqui
	}
}

func (r Resource) GetMeuexemplo(ctx context.Context, offset int64, limit int64) (itemsPage model.ItemsPage, err error) {
	startedAt := time.Now()
	defer r.log.Chronometer("MeuexemploService -> GetMeuexemplo", &startedAt)

	// <---- adicionado aqui: UMA LINHA = observabilidade completa
	tracker := r.observability.Track(ctx, "service.GetMeuexemplo.get_list")
	defer tracker.Finish(&err)

	tracker.AddParam("service.GetMeuexemplo.offset", offset)
	tracker.AddParam("service.GetMeuexemplo.limit", limit)

	itemsPage, err = r.meuexemploRepo.GetMeuexemplo(ctx, offset, limit)
	if err != nil {
		return itemsPage, errors.New(app.MsgRepositoryError)
	}

	// <---- adicionado aqui: Adicionar resultado
	if items, ok := itemsPage.Items.([]model.Meuexemplo); ok {
		tracker.AddResult("service.GetMeuexemplo.count", len(items))
		tracker.AddResult("service.GetMeuexemplo.total", itemsPage.Total)
	}

	return itemsPage, nil
}

func (r Resource) GetMeuexemploById(ctx context.Context, id int64) (meuexemplo *model.Meuexemplo, err error) {
	startedAt := time.Now()
	defer r.log.Chronometer("MeuexemploService -> GetMeuexemploById", &startedAt)

	tracker := r.observability.Track(ctx, "service.GetMeuexemploById")
	defer tracker.Finish(&err)

	tracker.AddParam("service.GetMeuexemploById.id", id)

	meuexemplo, err = r.meuexemploRepo.GetMeuexemploById(ctx, id)
	if err != nil {
		return nil, errors.New(app.MsgRepositoryError)
	}

	tracker.AddResult("service.GetMeuexemploById.found", meuexemplo != nil)
	return meuexemplo, nil
}

func (r Resource) GetMeuexemploByStatusCode(ctx context.Context, statuscode string) (meuexemplo *model.Meuexemplo, err error) {
	startedAt := time.Now()
	defer r.log.Chronometer("MeuexemploService -> GetMeuexemploByStatusCode", &startedAt)

	tracker := r.observability.Track(ctx, "service.GetMeuexemploByStatusCode")
	defer tracker.Finish(&err)

	tracker.AddParam("service.GetMeuexemploByStatusCode.status_code", statuscode)

	meuexemplo, err = r.meuexemploRepo.GetMeuexemploByStatusCode(ctx, statuscode)
	if err != nil {
		return nil, errors.New(app.MsgRepositoryError)
	}

	tracker.AddResult("service.GetMeuexemploByStatusCode.found", meuexemplo != nil)
	return meuexemplo, nil
}

func (r Resource) DeleteMeuexemploById(ctx context.Context, id int64) (result bool, err error) {
	startedAt := time.Now()
	defer r.log.Chronometer("MeuexemploService -> DeleteMeuexemploById", &startedAt)

	tracker := r.observability.Track(ctx, "service.DeleteMeuexemploById.delete")
	defer tracker.Finish(&err)

	tracker.AddParam("service.DeleteMeuexemploById.id", id)

	result, err = r.meuexemploRepo.DeleteMeuexemploById(ctx, id)
	if err != nil {
		return false, errors.New(app.MsgRepositoryError)
	}

	tracker.AddResult("service.DeleteMeuexemploById.deleted", result)
	return result, nil
}

func (r Resource) InsertMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo) (insertedID int64, err error) {
	startedAt := time.Now()
	defer r.log.Chronometer("MeuexemploService -> InsertMeuexemplo", &startedAt)

	tracker := r.observability.Track(ctx, "service.InsertMeuexemplo")
	defer tracker.Finish(&err)

	tracker.AddParam("service.InsertMeuexemplo.name", meuexemplo.Name)
	tracker.AddParam("service.InsertMeuexemplo.status_code", meuexemplo.StatusCode)

	insertedID, err = r.meuexemploRepo.InsertMeuexemplo(ctx, meuexemplo)
	if err != nil {
		return 0, errors.New(app.MsgRepositoryError)
	}

	tracker.AddResult("service.InsertMeuexemplo.inserted_id", insertedID)
	return insertedID, nil
}

func (r Resource) UpdateMeuexemplo(ctx context.Context, meuexemplo *model.Meuexemplo, id int64) (err error) {
	startedAt := time.Now()
	defer r.log.Chronometer("MeuexemploService -> UpdateMeuexemplo", &startedAt)

	tracker := r.observability.Track(ctx, "service.UpdateMeuexemplo")
	defer tracker.Finish(&err)

	tracker.AddParam("service.UpdateMeuexemplo.id", id)
	tracker.AddParam("service.UpdateMeuexemplo.name", meuexemplo.Name)
	tracker.AddParam("service.UpdateMeuexemplo.status_code", meuexemplo.StatusCode)

	err = r.meuexemploRepo.UpdateMeuexemplo(ctx, meuexemplo, id)
	if err != nil {
		return errors.New(app.MsgRepositoryError)
	}

	tracker.AddResult("service.UpdateMeuexemplo.updated", true)
	return nil
}
