package server

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"github.com/labstack/gommon/log"

	meuexemploHandler "novo-exemplo-palm-pay/app/meuexemplo/handler"
	meuexemploRepo "novo-exemplo-palm-pay/app/meuexemplo/repository"
	meuexemploSV "novo-exemplo-palm-pay/app/meuexemplo/service"

	"novo-exemplo-palm-pay/utils/observabilidade" // <---- adicionado aqui

	"github.com/tungstenbyte/utils/logger"
)

type App struct {
	httpServer *http.Server
	PGDBWrite  *pgxpool.Pool
	PGDBRead   *pgxpool.Pool
	log        logger.Logger
	// healthUC          healthUC.HealthUseCaseIF
	meuexemploSV meuexemploSV.MeuexemploServiceIF
}

type ServerIF interface {
	Start()
	Stop()
	Run(port string) error
}

func New() ServerIF {
	return &App{}
}

func (a *App) Start() {

	a.log = logger.NewApiLogger()
	a.log.InitLogger("Dpanic")

	// <---- adicionado aqui: Inicializar observabilidade completa
	if err := observabilidade.InitObservability("novo-exemplo-palm-pay", "1.0.0"); err != nil {
		log.Fatalf("Erro ao inicializar observabilidade: %v", err)
	}

	// <---- adicionado aqui: Iniciar servidor de métricas em goroutine separada
	go observabilidade.StartMetricsServer("2112")

	a.StartPGWrite()
	a.StartPGRead()
	// a.StartRedisCluster()

	meuexemploRepository := meuexemploRepo.NewMeuexemploRepository(a.PGDBWrite, a.PGDBRead, a.log)
	a.meuexemploSV = meuexemploSV.NewMeuexemploService(meuexemploRepository, a.log)

	// healthRepository := healthRepo.NewHealthRepository(a.PGDBRead, a.log)
	// a.healthUC = healthUC.NewHealthUseCase(healthRepository, a.log)
}

func (a *App) Run(port string) error {
	var (
		sig chan os.Signal
	)
	router := echo.New()
	router.HideBanner = true
	router.HidePort = true
	router.Server.ReadTimeout = 15 * time.Minute

	// <---- adicionado aqui: Middlewares de observabilidade em ordem específica
	router.Use(observabilidade.RequestIDMiddleware())                   // 1º - Request ID sempre primeiro
	router.Use(observabilidade.TimeoutMiddleware(30 * time.Second))     // 2º - Timeout padrão
	router.Use(observabilidade.StructuredLoggingMiddleware("global"))   // 3º - Log estruturado
	router.Use(middleware.Recover())                                    // 4º - Recovery do Echo
	router.Use(observabilidade.EnhancedHTTPMetricsMiddleware("global")) // 5º - Métricas HTTP

	// <---- adicionado aqui: Endpoint de health check com observabilidade
	router.GET("/health", func(c echo.Context) error {
		// <---- adicionado aqui: Health check simples com métricas
		start := time.Now()

		// Verificar conexões do banco
		ctxDB, cancel := context.WithTimeout(c.Request().Context(), 2*time.Second)
		defer cancel()

		health := map[string]interface{}{
			"status":    "healthy",
			"timestamp": time.Now().Format(time.RFC3339),
			"version":   "1.0.0",
			"service":   "novo-exemplo-palm-pay",
		}

		// Verificar PG Write
		if err := a.PGDBWrite.Ping(ctxDB); err != nil {
			health["status"] = "unhealthy"
			health["pg_write"] = "error: " + err.Error()
		} else {
			health["pg_write"] = "ok"
		}

		// Verificar PG Read
		if err := a.PGDBRead.Ping(ctxDB); err != nil {
			health["status"] = "unhealthy"
			health["pg_read"] = "error: " + err.Error()
		} else {
			health["pg_read"] = "ok"
		}

		health["response_time_ms"] = time.Since(start).Milliseconds()

		if health["status"] == "healthy" {
			return c.JSON(http.StatusOK, health)
		} else {
			return c.JSON(http.StatusServiceUnavailable, health)
		}
	})

	// <---- adicionado aqui: Endpoint de métricas interno (além do servidor separado)
	router.GET("/internal/metrics", func(c echo.Context) error {
		return c.JSON(http.StatusOK, map[string]interface{}{
			"metrics_endpoint":  "http://localhost:2112/metrics",
			"prometheus_format": true,
			"service":           "novo-exemplo-palm-pay",
		})
	})

	api := router.Group("/api")

	// health.RegisterHTTPEndpoints(api, a.healthUC, a.log)

	meuexemploHandler.RegisterMeuexemploHTTPEndpoints(api, a.meuexemploSV, a.log)

	a.httpServer = &http.Server{
		Addr:           ":" + port,
		Handler:        router,
		ReadTimeout:    10 * time.Second,
		WriteTimeout:   10 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}

	fmt.Println("≡ Microservices novo-exemplo-palm-pay Started in local Port: ", port, " ≡")
	fmt.Println("📊 Métricas disponíveis em: http://localhost:2112/metrics") // <---- adicionado aqui
	fmt.Println("🔍 Health check em: http://localhost:" + port + "/health")  // <---- adicionado aqui
	fmt.Println("")

	go func() {
		if err := a.httpServer.ListenAndServe(); err != nil {
			log.Fatalf("Failed to listen and serve: %+v", err)
		}
	}()

	quit1 := make(chan os.Signal, 1)
	// signal.Notify(quit, os.Interrupt, os.Interrupt)
	sig = make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGTERM, syscall.SIGHUP)

	<-quit1

	ctx, shutdown := context.WithTimeout(context.Background(), 5*time.Second)
	defer shutdown()
	return a.httpServer.Shutdown(ctx)
}

func (a *App) StartPGWrite() {
	var err error
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	url := os.Getenv("POSTGRESQL_WRITE_URL")

	config, err := pgxpool.ParseConfig(url)
	if err != nil {
		log.Fatal(ctx, "Failed to parse PostgreSQL config: ", err.Error())
	}

	config.MaxConns = 30
	config.MinConns = 5
	config.MaxConnLifetime = time.Hour
	config.MaxConnIdleTime = 30 * time.Minute

	a.PGDBWrite, err = pgxpool.NewWithConfig(ctx, config)

	if err != nil {
		log.Fatal(ctx, "Not connect DB Postgresql: ", err.Error())
	}

	if err := a.PGDBWrite.Ping(ctx); err != nil {
		log.Fatal(ctx, "Failed to ping PostgreSQL Write: ", err.Error())
	}

	// <---- adicionado aqui: Registrar métricas de conexão
	observabilidade.UpdateDBConnections(ctx, "meuexemplo", int(config.MaxConns))

	a.log.Info("DB Postgresql Writer was connected...")
}

func (a *App) StartPGRead() {
	var err error
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	url := os.Getenv("POSTGRESQL_READ_URL")

	config, err := pgxpool.ParseConfig(url)
	if err != nil {
		log.Fatal(ctx, "Failed to parse PostgreSQL config: ", err.Error())
	}

	config.MaxConns = 30
	config.MinConns = 5
	config.MaxConnLifetime = time.Hour
	config.MaxConnIdleTime = 30 * time.Minute

	a.PGDBRead, err = pgxpool.NewWithConfig(ctx, config)

	if err != nil {
		log.Fatal(ctx, "Not connect DB Postgresql: ", err.Error())
	}

	if err := a.PGDBRead.Ping(ctx); err != nil {
		log.Fatal(ctx, "Failed to ping PostgreSQL Read: ", err.Error())
	}

	// <---- adicionado aqui: Registrar métricas de conexão
	observabilidade.UpdateDBConnections(ctx, "meuexemplo", int(config.MaxConns))

	a.log.Info("DB Postgresql Readr was connected...")
}

func (a *App) stopPGWrite() {
	if a.PGDBWrite != nil {
		a.PGDBWrite.Close()
		a.log.Info("PG Write conexao finalizada ok")
	}
}

func (a *App) stopPGRead() {
	if a.PGDBRead != nil {
		a.PGDBRead.Close()
		a.log.Info("PG Read conexao finalizada ok")
	}
}

func (a *App) stopHttp() {
	a.httpServer.Close()
	a.log.Info("Http conexao finalizada ok")
}

func (a *App) Stop() {
	a.stopPGRead()
	a.stopPGWrite()
	// a.stopRedis()
	a.stopHttp()
	a.log.Info("Finalizado com sucesso")
}
